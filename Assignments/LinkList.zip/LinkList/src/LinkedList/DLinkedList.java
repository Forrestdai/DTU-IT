package LinkedList;

public class DLinkedList
{

    /**
     * // head tail // Node(data)->Node(data)->Node(data)->
     * Node(data)->Node(data)-> Node(data) // Add Node // Delete Node // find
     * node
     */
    int size = 0;
    Node head;
    Node tail;

    public void add(int data)
    {
// scenario 1:Empty linked list
// scenario 2:Non-empty linked list Node(5)->Node(6)-> Node(7)->Node(8)
// add Node(9)    
//         [Node(5)->Node(6)->Node(7)-> Node(8)->Node(9)] 

        // scenario 1:Empty linked list(if there is nothing in our list) 
        Node node = new Node(data);
        if (tail == null)
        {
            head = node;
            tail = node;
        } else
        {
            tail.nextNode = node;
            tail = node;

        }
        size++;
    }

    public Node delete(int data)
    {

// scenario 1:Empty linked list
// scenario 2:Non-empty linke list 
//delete find note(9)[Node(5)->Node(6)-> Node(7)->Node(8)]
// scenario 3:Delete element at tail
// scenario 4:Delete element at head
// scenario 5:Delete element in middle in list   
        Node nodeToReturn = null;
        if (size == 0)
        {
            return null;
        }
        if (size == 1)
        {
            nodeToReturn = head;
            head = null;
            tail = null;
            size--;
            return nodeToReturn;
        }

        Node nodeBeforeNodeToDelete = findNodeBefore(data);
//case where we need to delete the head
        if (nodeBeforeNodeToDelete.data == 0)
        {
            head = head.nextNode;
            size--;
        } else if (nodeBeforeNodeToDelete != null)
        {
// where we have found. this node represent before where we  want to delete   
            if (tail.data == data)
            {
                nodeBeforeNodeToDelete.nextNode = null;
                tail = nodeBeforeNodeToDelete;
            } else
            {

                nodeBeforeNodeToDelete.nextNode = nodeBeforeNodeToDelete.nextNode.nextNode.nextNode.nextNode.nextNode.nextNode;
            }
            size--;

        }

        return null;
    }
    // if this method returns an empty list, it means that the element that we want to delete 
    //is at the hed of the linkedList.
    //Returns null if there is no match,and returns  a populated if it found a match

    public Node findNodeBefore(int data)
    {
        if (head.data == data)
        {
            return new Node();
        }

        // check the first element for a match
        if (head.data == data)
        {
            return head;
        }
        //assign node as the iterator
        Node node = head;
        // iterate through our Linked List
        while (node.nextNode != null)
        {
            if (node.nextNode.data == data)
            {
                return node;
            }
            node = node.nextNode;

        }
        return null; // if wasn't found

    }

    public Node find(int data)
    {
//// scenario 1:Empty linked list
//// scenario 2:Non-empty linke list
//
        if (head == null)
        {

            return null;
        }
        // check the first element for a match
        if (head.data == data)
        {
            return head;
        }
        //assign node as the iterator
        Node node = head;
        // iterate through our Linked List
        while (head.nextNode != null)

        {
            node = node.nextNode;
            if (node.data == data)
            {
                return node;
            }
        }
        return null; // if wasn't found
    }

    void traverse()
    {
        if (head != null)
        {
            Node node = head;
            System.out.println(node);
            while (node.nextNode != null)
            {
                node = node.nextNode;
                System.out.println(node);

            }

        }

    }
}
