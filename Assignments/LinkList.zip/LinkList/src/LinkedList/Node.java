package LinkedList;

/**
 * @author sudhir
 */
public class Node{
    int data;
    Node nextNode;
    
public Node(int data){
    this.data=data;
}

    Node()
    {
        throw new UnsupportedOperationException(); //To change body of generated methods, choose Tools | Templates.
    }
// actual location on the memory
public String toString(){
        return "" + data; // just cast to the string 

}

}    
    
