package LinkedList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 *
 * @author sudhir
 */
public class LinkedListTest
{

    public LinkedListTest()
    {
    }

    @BeforeClass
    public static void setUpClass()
    {
    }

    @AfterClass
    public static void tearDownClass()
    {
    }

    @Before
    public void setUp()
    {
    }

    @After
    public void tearDown()
    {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void test()
    {

        DLinkedList list = new DLinkedList();
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);
        list.add(5);
        list.add(6);
        
        list.traverse();
        System.out.print(list.find(1));
        System.out.print(list.find(2));
        System.out.print(list.find(3));
        System.out.print(list.find(4));
        System.out.print(list.find(5));
        System.out.print(list.find(6));
    
        
       
       
        
        System.out.println("Deleting 6");
        list.delete(6);
        list.traverse();
        
      

   

    }
}
